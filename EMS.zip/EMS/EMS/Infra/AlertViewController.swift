//  AlertViewController.swift

import UIKit
protocol AlertViewControllerProtocol {
    func defaultButtonAction(alertController: UIAlertController)
}
class AlertViewController: UIViewController {
    var delegate: AlertViewControllerProtocol? = nil
}
// MARK: - Custom Actions
extension AlertViewController {
    func showSimpleAlert(title: String, message: String, preferredStyle: UIAlertControllerStyle, tag: NSInteger ) -> UIAlertController {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: preferredStyle)
        let defaultAction = UIAlertAction(title: NSLocalizedString("OK", comment: ""), style: .Default) {
            UIAlertAction in
            self.delegate?.defaultButtonAction(alertController)
        }
        alertController.addAction(defaultAction)
        alertController.view.tag = tag
        return alertController
    }
}
extension AlertViewControllerProtocol {
    func defaultButtonAction(alertController: UIAlertController) {
    }
}
