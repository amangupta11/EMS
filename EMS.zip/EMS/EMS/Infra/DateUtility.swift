//  DateUtility.swift

import Foundation
import UIKit

class DateUtility: NSObject{
    class func getCurrentTimeInGMT() -> NSTimeInterval {
        var date = NSDate()
        let dateFormatter = NSDateFormatter()
        let timeZone = NSTimeZone(name: "GMT")
        dateFormatter.timeZone = timeZone
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let gmtTimeZoneStr = dateFormatter.stringFromDate(date)
        date = dateFormatter.dateFromString(gmtTimeZoneStr)!
        let seconds = date.timeIntervalSince1970
        print("GMT TimeZone Str is =  \(gmtTimeZoneStr)")
        print("Seconds Str is =  \(seconds)")
        return seconds
    }
    class  func convertGMTtoShortDate(timeInterval: NSTimeInterval) -> String
    {
        let date = NSDate(timeIntervalSince1970: timeInterval)
        //Date formatting
        let dateFormatter = NSDateFormatter()
        dateFormatter.dateFormat = "dd MMM yyyy"
        let dateString = dateFormatter.stringFromDate(date)
        print("GMT to Short Date string =  \(dateString)")
        return dateString
    }
}
