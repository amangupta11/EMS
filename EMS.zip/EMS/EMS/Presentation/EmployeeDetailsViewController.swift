//  EmployeeDetailsViewController.swift

import UIKit
import Foundation
import CoreData

class EmployeeDetailsViewController: UIViewController {
    
    @IBOutlet weak var genderArrowImage: UIImageView!
    @IBOutlet weak var dobArrowImage: UIImageView!
    @IBOutlet weak var chnageProfilePic: UIButton!
    @IBOutlet weak var dobButtonOutlet: UIButton!
    @IBOutlet weak var submitButton: UIBarButtonItem!
    @IBOutlet weak var empGender: UIButton!
    @IBOutlet weak var empAddress: UITextView!
    @IBOutlet weak var empDesignation: UITextField!
    @IBOutlet weak var empNameLineLabel: UILabel!
    @IBOutlet weak var empProfilePic: UIImageView!
    @IBOutlet weak var empName: UITextField!
    @IBOutlet weak var empGenderLineLabel: UILabel!
    var imagePicker: UIImagePickerController? = nil
    var employeeInfo: EmployeeInfo? = nil
    var activeTextField: UITextField!
    var pickerContainerDelegate: PickerView!
    var submitButtonTag: Int = 0
    var genderArray: NSArray!
    var pickerContainerView: UIView!
    struct EmpDetailsStringConstants {
        static  var AlertTile = "Attention!"
        static  var AlertMsg = "Please Add Your Profile Picture."
        static  var SuccessFullySavedAlertMsg = "Your details has been saved successfully."
        static  var Submit = "Submit"
        static  var Edit = "Edit"
        static  var EmployeeInfo = "EmployeeInfo"
        static  var EmployeeGender = "EmployeeGender"
        static  var Gender = "Gender"
        static  var cameraGray = "cameraGray"
        static  var BackIcon = "Back_Icon"
        static  var Plist = "plist"
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    override func viewDidAppear(animated: Bool) {
        addKeyboardObserver(self)
        super.viewDidAppear(animated)
    }
    override func viewDidDisappear(animated: Bool) {
        removeKeyBoardObserver(self)
        super.viewDidDisappear(animated)
    }
    override func viewWillAppear(animated: Bool) {
        initialSetUp()
        if(employeeInfo != nil){
            updateUI()
            enableScreenInReadOnlyMode()
        }
    }
    // MARK: - Handling Obervers
    func addKeyboardObserver(viewController: UIViewController) {
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(self.keyboardWillShow(_:)), name: UIKeyboardWillShowNotification, object: nil)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(self.keyboardWillHide(_:)), name: UIKeyboardWillHideNotification, object: nil)
    }
    func removeKeyBoardObserver(viewController: UIViewController) {
        NSNotificationCenter.defaultCenter().removeObserver(self, name: UIKeyboardWillShowNotification, object: nil)
        NSNotificationCenter.defaultCenter().removeObserver(self, name: UIKeyboardWillHideNotification, object: nil)
    }
    
    
}
// MARK: - Custom Action Methods
extension  EmployeeDetailsViewController {
    func initialSetUp(){
        addTapGestureToImage()
        setTapGestureForView()
        setNavigationBackButtonImage()
        loadGenderValues()
        handleChangeProfilePicButton()
        setImageViewFrame()
    }
    func handleChangeProfilePicButton(){
        if(self.empProfilePic.image == UIImage(named: EmpDetailsStringConstants.cameraGray)){
            self.chnageProfilePic.hidden = true
        }else{
            self.chnageProfilePic.hidden = false
        }
    }
    func updateUI(){
        enableEditButton()
        let imageData = self.employeeInfo!.empProfilePic! as NSData
        self.empProfilePic.image = UIImage(data: imageData)
        self.empName.text = self.employeeInfo!.empName! as String
        self.empDesignation.text = self.employeeInfo!.empDesignation! as String
        self.empAddress.text = self.employeeInfo!.empAddress! as String
        self.empGender.setTitle(self.employeeInfo!.empGender!, forState: .Normal)
        self.dobButtonOutlet.setTitle(self.employeeInfo!.empDob!, forState: .Normal)
    }
    func enableScreenInReadOnlyMode(){
        self.chnageProfilePic.hidden = true
        self.empProfilePic.userInteractionEnabled = false
        self.empName.userInteractionEnabled = false
        self.empDesignation.userInteractionEnabled = false
        self.empAddress.userInteractionEnabled = false
        self.empGender.userInteractionEnabled = false
        self.dobButtonOutlet.userInteractionEnabled = false
        self.dobArrowImage.hidden = true
        self.genderArrowImage.hidden = true
    }
    func enableEditButton(){
        self.submitButton.title = EmpDetailsStringConstants.Edit
        self.submitButtonTag = 1
    }
    func addTapGestureToImage(){
        self.empProfilePic.userInteractionEnabled = true
        let addTapGesture = UITapGestureRecognizer()
        addTapGesture.addTarget(self, action: #selector(EmployeeDetailsViewController.presentCamera))
        self.empProfilePic.addGestureRecognizer(addTapGesture)
    }
    func setTapGestureForView() {
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(self.handleTap(_:) ))
        self.view.addGestureRecognizer(tapGesture)
    }
    func handleTap(sender: UIView) {
        view.endEditing(true)
    }
    func setNavigationBackButtonImage() {
        let image = UIImage(named: EmpDetailsStringConstants.BackIcon)
        let backButton = UIButton(type: UIButtonType.Custom)
        backButton.addTarget(self, action: #selector(backButtonAction), forControlEvents: UIControlEvents.TouchUpInside)
        backButton.imageEdgeInsets = UIEdgeInsets(top: 0, left: -30, bottom: 0, right: -10)
        backButton.setImage(image, forState: UIControlState.Normal)
        backButton.sizeToFit()
        let backButtonItem = UIBarButtonItem(customView: backButton)
        self.navigationItem.leftBarButtonItem = backButtonItem
    }
    func backButtonAction(button: UIButton) {
        self.navigationController?.popViewControllerAnimated(true)
    }
    func addPickerView(tag:Int) {
        self.view.endEditing(true)
        self.pickerContainerDelegate = PickerView(frame: self.navigationController!.view.frame)
        self.pickerContainerDelegate.delegate = self
        if(tag == 1){
            self.pickerContainerView = self.pickerContainerDelegate.datePickerView()
            var mindate: NSDate
            var maxdate: NSDate
            mindate = NSDate(timeIntervalSince1970: 315572884 )
            maxdate = NSDate(timeIntervalSince1970: 946724884 )
            self.pickerContainerDelegate.datePicker.minimumDate = mindate
            self.pickerContainerDelegate.datePicker.maximumDate = maxdate
        }
        else{
            addGenderPickerView()
        }
        self.pickerContainerView.backgroundColor = UIColor(red: 0 / 255.0, green: 0 / 255.0, blue: 0 / 255.0, alpha: 0.2)
        let window = UIApplication.sharedApplication().delegate?.window
        window!!.addSubview(self.pickerContainerView)
    }
    func addGenderPickerView(){
        var selectedIndex: Int = 0
        if self.empGender.titleLabel!.text?.characters.count > 0 {
            for i in 0..<self.genderArray.count {
                if self.empGender.titleLabel!.text == self.genderArray[i] as? String {
                    selectedIndex = i
                    break
                }
            }
        }
        self.view.endEditing(true)
        self.pickerContainerDelegate = PickerView(frame: self.navigationController!.view.frame)
        self.pickerContainerDelegate.delegate = self
        self.pickerContainerDelegate.index = selectedIndex
        self.pickerContainerView = self.pickerContainerDelegate.customPickerView(self.genderArray)
    }
    func loadGenderValues() {
        let metaDataPList: NSDictionary!
        let path = NSBundle.mainBundle().pathForResource(EmpDetailsStringConstants.EmployeeGender, ofType: EmpDetailsStringConstants.Plist)
        metaDataPList = NSDictionary(contentsOfFile: path!)
        self.genderArray = (metaDataPList.objectForKey(EmpDetailsStringConstants.Gender) as? NSArray)!
    }
    func setImageViewFrame(){
        self.empProfilePic.layer.frame = CGRectInset(self.empProfilePic.layer.frame, 0, 0)
        self.empProfilePic.layer.borderColor = UIColor.grayColor().CGColor
        self.empProfilePic.layer.cornerRadius = self.empProfilePic.frame.height/2
        self.empProfilePic.layer.masksToBounds = false
        self.empProfilePic.clipsToBounds = true
        self.empProfilePic.layer.borderWidth = 0.5
        self.empProfilePic.contentMode = UIViewContentMode.ScaleAspectFill
    }
    func handleSumbitButtonAction(){
        if(self.submitButtonTag == 0){
            self.normalizeTheLabelsColor()
            self.view.endEditing(true)
            let isValid = self.validateFields()
            if(isValid == true){
                saveData()
            }
        }
        else{
            enableScreenToEditMode()
        }
    }
    
    func saveData(){
        if(employeeInfo == nil){
            employeeInfo = NSEntityDescription.insertNewObjectForEntityForName(EmpDetailsStringConstants.EmployeeInfo , inManagedObjectContext: CoreData.sharedCoreData.mainThreadContext) as? EmployeeInfo
        }
        employeeInfo?.empName = self.empName.text!
        employeeInfo?.empDesignation = self.empDesignation.text!
        employeeInfo?.empDob = (self.dobButtonOutlet.titleLabel?.text)!
        employeeInfo?.empGender = (self.empGender.titleLabel?.text)!
        employeeInfo?.empAddress = self.empAddress.text
        employeeInfo?.empRecordDate = DateUtility.convertGMTtoShortDate(DateUtility.getCurrentTimeInGMT())
        let imageData = NSData(data: UIImageJPEGRepresentation(self.empProfilePic.image!, 1.0)!)
        employeeInfo?.empProfilePic = imageData
        CoreData.sharedCoreData.saveContext()
        showAlert("", alertMsg: EmpDetailsStringConstants.SuccessFullySavedAlertMsg, tag:1)
    }
    
    func enableScreenToEditMode(){
        self.submitButton.title = EmpDetailsStringConstants.Submit
        self.submitButtonTag == 0
        self.empName.userInteractionEnabled = true
        self.empDesignation.userInteractionEnabled = true
        self.empGender.userInteractionEnabled = true
        self.empAddress.userInteractionEnabled = true
        self.dobButtonOutlet.userInteractionEnabled = true
        self.empProfilePic.userInteractionEnabled = true
        self.chnageProfilePic.hidden = false
        self.dobArrowImage.hidden = false
        self.genderArrowImage.hidden = false
        self.submitButtonTag = 0
    }
    
    
    
    func normalizeTheLabelsColor(){
        self.empNameLineLabel.backgroundColor = UIColor.lightGrayColor()
        self.empGenderLineLabel.backgroundColor = UIColor.lightGrayColor()
    }
    func validateFields() -> Bool{
        var isValid = true
        if(self.empProfilePic.image == UIImage(named: EmpDetailsStringConstants.cameraGray)){
            showAlert(EmpDetailsStringConstants.AlertTile, alertMsg: EmpDetailsStringConstants.AlertMsg, tag:0)
            isValid = false
        }
        if(empName.text?.isEmpty == true){
            self.empNameLineLabel.backgroundColor = UIColor.redColor()
            isValid = false
        }
        if(empGender.titleLabel?.text?.isEmpty == true || empGender.titleLabel?.text == nil){
            self.empGenderLineLabel.backgroundColor = UIColor.redColor()
            isValid = false
        }
        return isValid
    }
    func showAlert(alertTile: String, alertMsg: String, tag: Int) {
        let alertController = AlertViewController()
        alertController.delegate = self
        let alertView = alertController.showSimpleAlert(alertTile, message:alertMsg, preferredStyle: UIAlertControllerStyle.Alert, tag: tag)
        self.presentViewController(alertView, animated: true, completion: nil)
    }
}

// MARK: - @IBActions
extension  EmployeeDetailsViewController {
    
    @IBAction func chnageProfilePic(sender: AnyObject) {
        self.presentCamera()
    }
    @IBAction func selectGender(sender: AnyObject) {
        addPickerView(2)
    }
    @IBAction func submitButtonAction(sender: AnyObject) {
        handleSumbitButtonAction()
    }
    
    @IBAction func dobButtonAction(sender: AnyObject) {
        addPickerView(1)
    }
}
// MARK: - PickerView Delegates
extension  EmployeeDetailsViewController:pickerViewProtocol {
    // MARK: - Picker Delegates
    func datePickerDoneButtonTapped(selectedDate: String!) {
        self.dobButtonOutlet.setTitle(selectedDate as String, forState: .Normal)
    }
    func pickerViewDoneButtonTapped(selectedString: String!, index: Int) {
        self.empGender.setTitle(self.genderArray[index] as? String, forState: .Normal)
    }
}
// MARK: - Adding Camera Launcher
extension EmployeeDetailsViewController:UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    func presentCamera() {
        imagePicker = UIImagePickerController()
        imagePicker?.navigationBar.backgroundColor = UIColor(red: 0.0 / 255.0, green: 75.0 / 255.0, blue: 135.0 / 255.0, alpha: 1.0)
        self.takePhoto()
    }
    func takePhoto() {
        imagePicker!.delegate = self
        if UIImagePickerController .isSourceTypeAvailable(UIImagePickerControllerSourceType.Camera) {
            imagePicker!.sourceType = .Camera
        } else   if UIImagePickerController .isSourceTypeAvailable(UIImagePickerControllerSourceType.PhotoLibrary) {
            // Camera not available
            imagePicker!.sourceType = .PhotoLibrary
        }
        imagePicker!.allowsEditing = false
        self.presentViewController(imagePicker!, animated: true, completion: nil)
    }
    // MARK: - Image Picker Delegates
    func imagePickerController(
        picker: UIImagePickerController,
        didFinishPickingMediaWithInfo info: [String : AnyObject]) {
        if let pickedImage = info[UIImagePickerControllerOriginalImage] as? UIImage {
            self.empProfilePic.image = pickedImage
            setImageViewFrame()
        }
        imagePicker! .dismissViewControllerAnimated(true, completion: nil)
    }
    func imagePickerControllerDidCancel(picker: UIImagePickerController) {
        imagePicker!.dismissViewControllerAnimated(true, completion: nil)
    }
}
// MARK: - textField Delegates
extension  EmployeeDetailsViewController:UITextFieldDelegate {
    func textFieldDidBeginEditing(textField: UITextField) {
        self.activeTextField = textField
    }
    func textField(textField: UITextField, shouldChangeCharactersInRange range: NSRange, replacementString string: String) -> Bool {
        let updatedString = (textField.text as NSString?)?.stringByReplacingCharactersInRange(range, withString: string)
        if updatedString?.characters.count > 20 {
            return false
        }
        return true
    }
    func textFieldDidEndEditing(textField: UITextField) {
        self.activeTextField = nil
    }
}
// MARK: - textView Delegates
extension  EmployeeDetailsViewController:UITextViewDelegate {
    func textView(textView: UITextView, shouldChangeTextInRange range: NSRange, replacementText text: String) -> Bool {
        let updatedString = (textView.text as NSString?)?.stringByReplacingCharactersInRange(range, withString: text)
        if updatedString?.characters.count > 200 {
            return false
        }
        return true
    }
}
//MARK: - Keyboard Notification Handling
extension EmployeeDetailsViewController {
    func keyboardWillHide(notification: NSNotification) {
        UIView.animateWithDuration(0.25, animations: { () -> Void in
            self.view.frame.origin.y = 64})
    }
    func keyboardWillShow(notification: NSNotification) {
        if(self.activeTextField != nil){
            if(self.activeTextField == empName || self.activeTextField == empDesignation){
                return
            }}
        if let keyboardSize = (notification.userInfo?[UIKeyboardFrameEndUserInfoKey] as? NSValue)?.CGRectValue() {
            UIView.animateWithDuration(0.25, animations: { () -> Void in
                self.view.frame.origin.y = -keyboardSize.height+70})
        }
    }
}
//MARK: - AlertView Delegate
extension EmployeeDetailsViewController: AlertViewControllerProtocol {
    func defaultButtonAction(alertController: UIAlertController) {
        if(alertController.view.tag == 1){
            self.navigationController?.popToRootViewControllerAnimated(true)
        }
        alertController.dismissViewControllerAnimated(true, completion: nil)
    }
}

