//  HomeViewController.swift

import UIKit
import Foundation
import CoreData
class HomeViewController: UIViewController {
    
    @IBOutlet weak var searchEmployee: UIBarButtonItem!
    @IBOutlet weak var employeeListTableView: UITableView!
    @IBOutlet weak var addEmployee: UIBarButtonItem!
    @IBOutlet weak var sortByAddedDate: UIButton!
    @IBOutlet weak var todaysReport: UILabel!
    @IBOutlet weak var totalEmployees: UILabel!
    var employeeInfo: EmployeeInfo!
    var searchBar = UISearchBar()
    var searchText = ""
    var fetchTodaysRecord: NSFetchedResultsController!
    var fetchAllEmployeesRecord: NSFetchedResultsController!
    struct HomeScreenStringConstants {
    static  var CellIdentifier = "HomeTableViewCell"
    static  var StoryboardName = "Main"
    static  var StoryboardScreenName = "EmployeeDetailsScreen"
    static  var EntityName = "EmployeeInfo"
    static  var EmpRecorddate = "empRecordDate"
    static  var DateFormat = "dd MMM yyyy"
    static  var Today = "Today"
    static  var Yesterday = "Yesterday"
    static  var HomeScreenTitle = "Employees Records"
    static  var EmpDOB = "empDob"
        
    }
    // MARK: - UIView Life Cycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    override func viewWillAppear(animated: Bool) {
        initialSetUp()
    }
}
// MARK: - @IBActions
extension  HomeViewController{
    
    @IBAction func searchBarButtonAction(sender: AnyObject) {
        showSearchBar()
    }
    
    @IBAction func sortByBirthDateButtonAction(sender: AnyObject) {
        sortRecordsByBirthDate()
    }
}

// MARK: - Custom Methods
extension  HomeViewController: NSFetchedResultsControllerDelegate {
    func initialSetUp(){
        fetchAllEmployeeRecords()
        reloadData()
        fetchTodaysRecords()
        self.employeeListTableView.contentOffset.y = 0
        searchBar.searchBarStyle = UISearchBarStyle.Minimal
        searchBar.delegate = self
    }
    func showSearchBar() {
        searchBar.alpha = 0
        searchBar.hidden = false
        self.searchBar.text = ""
        navigationItem.titleView = searchBar
        searchBar.showsCancelButton = true
        searchBar.tintColor = UIColor.whiteColor()
        navigationItem.setLeftBarButtonItem(nil, animated: true)
        UIView.animateWithDuration(0.5, animations: {
            self.searchBar.alpha = 1
            }, completion: { finished in
                self.searchBar.becomeFirstResponder()
        })
    }
    func reloadTable() {
        self.searchRecordsByName()
        self.employeeListTableView.reloadData()
    }
    func hideSearchBar() {
        searchBar.showsCancelButton = false
        searchBar.hidden = true
        self.navigationItem.titleView = nil
        self.navigationItem.title = HomeScreenStringConstants.HomeScreenTitle
    }
    
    func fetchAllEmployeeRecords(){
        let fetchRequest = NSFetchRequest(entityName: HomeScreenStringConstants.EntityName)
        let sortDescriptor = NSSortDescriptor(key: HomeScreenStringConstants.EmpRecorddate, ascending: false)
        fetchRequest.sortDescriptors = [sortDescriptor]
        fetchAllEmployeesRecord = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: DataOperation.sharedDataOperation.mainThreadContext, sectionNameKeyPath: nil, cacheName: nil)
        fetchAllEmployeesRecord.delegate = self
    }
    func searchRecordsByName(){
        if self.searchText.isEmpty == false {
            let predicate = NSPredicate(format: "empName == %@", self.searchText)
            fetchAllEmployeesRecord.fetchRequest.predicate = predicate
        }
        else {
            fetchAllEmployeesRecord.fetchRequest.predicate = nil
        }
        self.performFetchRecords(fetchAllEmployeesRecord)
    }
    func sortRecordsByBirthDate(){
        let sortDescriptor = NSSortDescriptor(key: HomeScreenStringConstants.EmpDOB, ascending: false)
        self.fetchAllEmployeesRecord.fetchRequest.sortDescriptors = [sortDescriptor]
        self.performFetchRecords(fetchAllEmployeesRecord)
        self.employeeListTableView.reloadData()
        self.employeeListTableView.contentOffset.y = 0
    }
    
    func fetchTodaysRecords() {
        let currentDate = DateUtility.getCurrentTimeInGMT()
        let fetchRequest = NSFetchRequest(entityName: HomeScreenStringConstants.EntityName)
        let sortDescriptor = NSSortDescriptor(key: HomeScreenStringConstants.EmpRecorddate, ascending: false)
        fetchRequest.sortDescriptors = [sortDescriptor]
        let predicate = NSPredicate(format: "empRecordDate == %@", DateUtility.convertGMTtoShortDate(currentDate))
        fetchRequest.predicate = predicate
        fetchTodaysRecord = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: DataOperation.sharedDataOperation.mainThreadContext, sectionNameKeyPath: nil, cacheName: nil)
        performFetchRecords(fetchTodaysRecord)
        self.todaysReport.text = String(Int((fetchTodaysRecord.fetchedObjects?.count)!))
    }
    func performFetchRecords(fetchResultController:NSFetchedResultsController){
        do{
            try fetchResultController.performFetch()
        } catch {
            fatalError("Failed to initialize FetchedResultsController: \(error)")
        }
    }
    
    func reloadData(){
        performFetchRecords(self.fetchAllEmployeesRecord)
        self.totalEmployees.text =  String(Int((fetchAllEmployeesRecord.fetchedObjects?.count)!))
        self.employeeListTableView.reloadData()
    }
    func configureCellData(cell: HomeTableViewCell, indexpath: NSIndexPath){
        employeeInfo = self.fetchAllEmployeesRecord.objectAtIndexPath(indexpath) as! EmployeeInfo
        var empRecordDateString: String
        let imageData = self.employeeInfo.empProfilePic! as NSData
        cell.empProfilePic.image = UIImage(data: imageData)
        cell.empDOB.text = self.employeeInfo.empDob! as String
        cell.empName.text = self.employeeInfo.empName! as String
        empRecordDateString = self.employeeInfo.empRecordDate! as String
        cell.empGender.text = self.employeeInfo.empGender! as String
        addjustImageViewFrame(cell)
        handleUIForEmpRecordCreatedDate(empRecordDateString, cell: cell)
    }
    func handleUIForEmpRecordCreatedDate(empRecordDateString:String, cell:HomeTableViewCell){
        let dateFormatter = NSDateFormatter()
        dateFormatter.dateFormat = HomeScreenStringConstants.DateFormat
        let currentDateString = DateUtility.convertGMTtoShortDate(DateUtility.getCurrentTimeInGMT())
        let currentDate = dateFormatter.dateFromString(currentDateString)
        let empRecordDate = dateFormatter.dateFromString(empRecordDateString)
        let yesterdayDate = currentDate?.dateByAddingTimeInterval(-86400.0)
        if currentDate!.earlierDate(empRecordDate!).isEqualToDate(currentDate!)  {
            cell.createdDate.text = HomeScreenStringConstants.Today
        }
        else if yesterdayDate!.earlierDate(empRecordDate!).isEqualToDate(yesterdayDate!){
            cell.createdDate.text = HomeScreenStringConstants.Yesterday
        }
        else{
            cell.createdDate.text = empRecordDateString
        }
    }
    func addjustImageViewFrame(cell:HomeTableViewCell){
        cell.empProfilePic.layer.frame = CGRectInset(cell.empProfilePic.layer.frame, 0, 0)
        cell.empProfilePic.layer.borderColor = UIColor.grayColor().CGColor
        cell.empProfilePic.layer.cornerRadius = cell.empProfilePic.frame.height/2
        cell.empProfilePic.layer.masksToBounds = false
        cell.empProfilePic.clipsToBounds = true
        cell.empProfilePic.layer.borderWidth = 0.5
        cell.empProfilePic.contentMode = UIViewContentMode.ScaleAspectFill
    }
    
    func navigateToEmployeeInformationScreen(employeeInfo:EmployeeInfo) {
        let vc: EmployeeDetailsViewController = UIStoryboard(name: HomeScreenStringConstants.StoryboardName, bundle: nil).instantiateViewControllerWithIdentifier(HomeScreenStringConstants.StoryboardScreenName) as! EmployeeDetailsViewController
        vc.employeeInfo = employeeInfo
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
}
// MARK: - tableView DataSource methods
extension  HomeViewController:UITableViewDataSource {
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier(HomeScreenStringConstants.CellIdentifier, forIndexPath: indexPath) as! HomeTableViewCell
        configureCellData(cell, indexpath: indexPath)
        return cell
    }
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        let selectedEmployeeInfo = self.fetchAllEmployeesRecord.objectAtIndexPath(indexPath) as! EmployeeInfo
        navigateToEmployeeInformationScreen(selectedEmployeeInfo)
    }
}

// MARK: - tableView Delegate methods
extension  HomeViewController:UITableViewDelegate {
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        if let sections = fetchAllEmployeesRecord.sections {
            return sections.count
        }
        return 0
    }
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if let sections = fetchAllEmployeesRecord.sections {
            let currentSection = sections[section]
            return currentSection.numberOfObjects
        }
        return 0
    }
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 65
    }
    func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        return true
    }
    
    func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if (editingStyle == UITableViewCellEditingStyle.Delete) {
            let selectedEmployeeInfo = self.fetchAllEmployeesRecord.objectAtIndexPath(indexPath) as! EmployeeInfo
            DataOperation.sharedDataOperation.deleteManagedObject(selectedEmployeeInfo)
            performFetchRecords(self.fetchAllEmployeesRecord)
            self.employeeListTableView.reloadData()
            self.initialSetUp()
        }
    }
}
//MARK: SearchBarDelegate
extension HomeViewController : UISearchBarDelegate{
    //MARK: UISearchBarDelegate
    func searchBarCancelButtonClicked(searchBar: UISearchBar) {
        hideSearchBar()
        self.searchText = ""
        searchBar.endEditing(true)
        self.reloadTable()
    }
    func searchBarSearchButtonClicked(searchBar: UISearchBar) {
        hideSearchBar()
        searchBar.resignFirstResponder()
        self.searchText = ""
        self.reloadTable()
    }
    func searchBar(searchBar: UISearchBar, textDidChange searchText: String) {
        self.searchText = searchText
        self.reloadTable()
    }
    func searchBar(searchBar: UISearchBar, shouldChangeTextInRange range: NSRange, replacementText text: String) -> Bool {
        let updatedString = (searchText as NSString?)?.stringByReplacingCharactersInRange(range, withString: text)
        if( updatedString == " "){
            return false
        }
        return true
    }
}
