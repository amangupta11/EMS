//  HomeTableViewCell.swift

import UIKit

class HomeTableViewCell: UITableViewCell {
    @IBOutlet weak var empProfilePic: UIImageView!
    @IBOutlet weak var createdDate: UILabel!
    @IBOutlet weak var empGender: UILabel!
    @IBOutlet weak var empDOB: UILabel!
    @IBOutlet weak var empName: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
