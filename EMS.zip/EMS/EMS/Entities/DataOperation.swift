//
//  DataOperation.swift

import UIKit
import CoreData
import Foundation
class DataOperation: NSObject {
    // MARK: - Private Properties
    var mainThreadContext: NSManagedObjectContext
    // MARK: - Shared Instance
    class var sharedDataOperation: DataOperation {
        struct Singleton {
            static let instance = DataOperation()
        }
        return Singleton.instance
    }
    // MARK: - Init
    override init() {
        self.mainThreadContext = CoreData.sharedCoreData.mainThreadContext
    }
    // MARK: - DB Insert
    func insertNewObjectForEntityForName(entityName: String, context: NSManagedObjectContext? = nil) -> AnyObject {
        var moc = mainThreadContext
        if let manageObjcontext = context {
            moc = manageObjcontext
        }
        return NSEntityDescription.insertNewObjectForEntityForName(entityName, inManagedObjectContext: moc)
    }
    // MARK: - DB Delete
    func deleteManagedObject(managedObject: NSManagedObject) {
        mainThreadContext.deleteObject(managedObject)
        do {
            if mainThreadContext.hasChanges {
                try mainThreadContext.save()
            }
        } catch let error as NSError {
            debugPrint(error)
        }
    }
}
