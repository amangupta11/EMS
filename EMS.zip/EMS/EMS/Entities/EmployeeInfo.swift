//  EmployeeInfo.swift

import Foundation
import CoreData

enum EmployeeInfoKey: String {
    case EmployeeInfo       = "EmployeeInfo"
}
class EmployeeInfo: NSManagedObject {
    class func insertNewEmployeeInfo(employeeInfo:EmployeeInfo) -> EmployeeInfo? {
        //var employeeInfo: EmployeeInfo?
        //if employeeInfo == nil {
            //employeeInfo =  DataOperation.sharedDataOperation.insertNewObjectForEntityForName(EmployeeInfoKey.EmployeeInfo.rawValue) as? EmployeeInfo
        //}
        do {
            DataOperation.sharedDataOperation.insertNewObjectForEntityForName(EmployeeInfoKey.EmployeeInfo.rawValue) as? EmployeeInfo
            if DataOperation.sharedDataOperation.mainThreadContext.hasChanges {
                try DataOperation.sharedDataOperation.mainThreadContext.save()
            }
        } catch {
            let saveError = error as NSError
            print("\(saveError), \(saveError.userInfo)")
        }
        return employeeInfo
    }
}
