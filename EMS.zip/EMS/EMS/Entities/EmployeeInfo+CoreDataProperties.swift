//  EmployeeInfo+CoreDataProperties.swift

import Foundation
import CoreData
extension EmployeeInfo {
    @NSManaged var empDob: String?
    @NSManaged var empAddress: String?
    @NSManaged var empName: String?
    @NSManaged var empGender: String?
    @NSManaged var empProfilePic: NSData?
    @NSManaged var empDesignation: String?
    @NSManaged var empRecordDate: NSNumber?
}

